import routeArray from "./route";
import commonutils from "../../utils/commonUtils";

export default (prefix:String) => commonutils.routeArray(routeArray, prefix);
